/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circleapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ercv1
 */
public class CircleApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        ArrayList<Circle> lista = new ArrayList<Circle>();
        char userResponse;
        do {
            System.out.print("Desea crear un circulo? (s/n):");
            userResponse = entrada.next().charAt(0);  //solo va a utiliza el primer caracter del string
            if (userResponse == 's') {
                System.out.print("Entrada un nuevo radio: ");
                double radio = entrada.nextDouble();
                Circle circulo = new Circle(radio);
                lista.add(circulo);
            }
        } while (userResponse == 's');
        System.out.println("Estos son los Circulos: ");
        for (Circle c:lista){
        System.out.println("El radio es: "+c.getRadius());
        System.out.println("El area es: "+c.area());
        System.out.println("La circunferencia es: "+c.circumference());
        System.out.println("*****************************************");
        }
    }

}
