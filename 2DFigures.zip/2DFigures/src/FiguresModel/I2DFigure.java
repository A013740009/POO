/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FiguresModel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author migue
 */
public interface I2DFigure {
    public void Show(Graphics g, Color color);
    public boolean Select(Point p);
    public void SetPosition(Point position);
    public Point GetPosition();
}
